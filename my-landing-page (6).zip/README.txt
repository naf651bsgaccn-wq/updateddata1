# Registration Form Landing Page

## How to Deploy on Netlify

1. Go to https://app.netlify.com and log in.
2. Click "Add new site" → "Deploy manually".
3. Unzip this folder (`my-landing-page.zip`) on your computer.
4. Drag and drop the **unzipped folder** into Netlify.
5. Your site will be live in seconds!

You can change the site name in settings if you want.
